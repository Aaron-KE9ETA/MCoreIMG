#!/usr/bin/env python3
"""Benchmark the codec against the real sample corpus.

Reports payload characters, frame count, encode time, palette size, geometric
deviation from the source outlines, and round-trip integrity.

    python tools/measure.py [--verbose]
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import build_corpus, load_constructor, REFERENCE


def deviation(source, decoded, m):
    """Worst distance from an original vertex to the decoded outline."""
    worst = 0.0
    for a, b in zip(source, decoded):
        if a.opcode != b.opcode:
            continue
        try:
            pa, pb = m.command_points(a), m.command_points(b)
        except Exception:
            continue
        if len(pb) < 2:
            continue
        for point in pa:
            best = min(m._perpendicular_distance(point, pb[i], pb[i + 1])
                       for i in range(len(pb) - 1))
            worst = max(worst, best)
    return worst


def main():
    verbose = "--verbose" in sys.argv
    ctor = load_constructor()
    m = ctor.mci
    corpus = build_corpus(ctor)
    if not corpus:
        print("No samples found; expected files under samples/.")
        return 1

    print(f"build={ctor.CONSTRUCTOR_BUILD}  protocol={m.PROTOCOL_VERSION}")
    print(f"{'case':18s} {'ref':>6s} {'chars':>6s} {'delta':>8s} {'fr':>3s} "
          f"{'ms':>7s} {'pal':>4s} {'devpx':>6s}  round trip")

    total = reference_total = 0
    failures = 0
    for name, cmds in corpus.items():
        t0 = time.perf_counter()
        enc = m.encode_image(cmds)
        elapsed = (time.perf_counter() - t0) * 1000

        ok = "n/a"
        dev = 0.0
        if enc.stats.fits:
            decoded = m.decode_frames(enc.frames)
            ok = "ok" if len(decoded) == len(cmds) else "COMMAND COUNT"
            dev = deviation(cmds, decoded, m)
        if ok not in ("ok", "n/a"):
            failures += 1

        chars = enc.stats.base91_chars
        ref = REFERENCE.get(name, 0)
        total += chars
        reference_total += ref
        delta = f"{100 * (chars - ref) / ref:+.2f}%" if ref else "--"
        print(f"{name:18s} {ref:6d} {chars:6d} {delta:>8s} {enc.stats.frame_count:3d} "
              f"{elapsed:7.0f} {enc.stats.palette_count:4d} {dev:6.2f}  {ok}")
        if verbose:
            s = enc.stats
            print(f"{'':18s} mode={'rc' if s.coding_mode else 'raw'} "
                  f"extent={s.local_group_extent} repeats={s.repeat_count} "
                  f"groups={s.transformed_group_count}")

    delta = (f"{100 * (total - reference_total) / reference_total:+.2f}%"
             if reference_total else "--")
    print(f"{'TOTAL':18s} {reference_total:6d} {total:6d} {delta:>8s}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
