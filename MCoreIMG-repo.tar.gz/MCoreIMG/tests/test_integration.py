#!/usr/bin/env python3
"""Cross-module integration checks.

Covers the seams the per-module self-tests cannot: that the four modules agree
about the protocol, that a frame set survives the full authoring-to-receiving
path, and that malformed input is refused rather than rendered.

    python tests/test_integration.py
"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
from harness import FITS, ROOT, SAMPLES, build_corpus, load_constructor, load_codec

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f" - {detail}" if detail and not ok else ""))


def run(args):
    return subprocess.run([sys.executable] + args, cwd=ROOT,
                          capture_output=True, text=True, env=dict(os.environ))


def main():
    codec = load_codec()
    ctor = load_constructor()

    print("[1] Module layering")
    check("codec exposes no GUI symbols",
          not any(hasattr(codec, n) for n in ("ConstructorApp", "render_to_pillow", "import_svg")))
    check("codec __all__ resolves", all(hasattr(codec, n) for n in codec.__all__))
    check("constructor defines no codec of its own",
          ctor.encode_image is ctor.mci.encode_image)
    check("one shared codec instance", ctor.mci is sys.modules.get("mcoreimg_compression"))
    check("model imports only stdlib",
          "MCoreIMG-compression" not in Path(ROOT, "MCoreIMG-model.py").read_text().split('"""')[2])

    print("\n[2] Command line")
    r = run(["MCoreIMG-Constructor.py", "--version"])
    check("constructor --version", r.returncode == 0 and "protocol=7" in r.stdout, r.stderr[:120])
    check("--version reports the whole chain",
          "codec=" in r.stdout and "model=" in r.stdout)
    r = run(["MCoreIMG-Constructor.py", "--self-test"])
    check("constructor --self-test", "PASS" in r.stdout, r.stderr[:200])
    r = run(["MCoreIMG-Reconstructor.py", "--self-test"])
    check("reconstructor --self-test", "PASS" in r.stdout, r.stderr[:200])

    print("\n[3] Round trips on real samples")
    m = ctor.mci
    all_samples = build_corpus(ctor)
    for name, cmds in all_samples.items():
        if FITS.get(name, True):
            continue
        enc = m.encode_image(cmds)
        check(f"{name} is reported over budget", not enc.stats.fits and enc.stats.frame_count > m.MAX_MESSAGES)
        check(f"{name} emits no frames or parity when over budget", not enc.frames and not enc.parity_frames)
    corpus = {name: cmds for name, cmds in all_samples.items() if FITS.get(name, True)}
    for name, cmds in corpus.items():
        enc = m.encode_image(cmds)
        check(f"{name} fits the envelope", enc.stats.fits)
        if enc.stats.fits:
            decoded = m.decode_frames(enc.frames)
            check(f"{name} round trip", len(decoded) == len(cmds))
            check(f"{name} frames within envelope",
                  len(enc.frames) <= m.MAX_MESSAGES
                  and all(len(f) <= m.MESSAGE_LEN for f in enc.frames))

    print("\n[4] End to end through both tools")
    sample = next(iter(corpus.values()))
    enc = m.encode_image(sample)
    tmp = Path(tempfile.mkdtemp())
    (tmp / "t.mci").write_text("\n".join(enc.frames) + "\n")
    r = run(["MCoreIMG-Reconstructor.py", str(tmp / "t.mci"), "-o", str(tmp / "t.png"),
             "--no-open", "--dump-json"])
    check("reconstructor writes PNG", (tmp / "t.png").exists(), r.stderr[:200])
    check("reconstructor writes JSON", (tmp / "t.mci.json").exists())
    if (tmp / "t.mci.json").exists():
        # The dump is a best-effort recovery: editor grouping and layer labels
        # are never transmitted, so a reload cannot reproduce the original
        # frames. What must hold is that it loads and carries the same commands.
        reloaded = ctor.load_source(tmp / "t.mci.json")
        decoded = m.decode_frames(enc.frames)
        check("dumped JSON reloads with the same commands",
              len(reloaded.commands) == len(decoded))

    print("\n[5] Determinism and scale independence")
    check("encoding is deterministic",
          list(m.encode_image(sample).frames) == list(m.encode_image(sample).frames))
    sizes = {}
    for scale in (1.0, 0.5, 0.1):
        doc = ctor.VectorDocument(commands=[c.clone() for c in sample], scale=scale)
        sizes[scale] = m.encode_image(doc.transformed_commands()).stats.bit_count
    # Local-space groups keep geometry cost independent of display scale, but
    # the per-object tolerance search budgets by on-canvas feature size, so a
    # heavily shrunk document gets a tighter budget and simplifies less. The
    # guarantee is therefore "within about a percent", not "identical".
    spread = (max(sizes.values()) - min(sizes.values())) / max(sizes.values())
    check("payload near-stable across display scale", spread <= 0.02,
          f"{sizes} spread {spread:.1%}")

    print("\n[6] Malformed input is refused")
    def rejects(frames):
        try:
            m.decode_frames(frames)
            return False
        except m.MCIError:
            return True
    frames = list(enc.frames)
    check("rejects truncated set", rejects(frames[:-1]) if len(frames) > 1 else True)
    bad = list(frames)
    body = bad[0][m.FRAME_HEADER_LEN:]
    bad[0] = bad[0][:m.FRAME_HEADER_LEN] + ("!" if body[0] != "!" else "#") + body[1:]
    check("rejects corrupted payload", rejects(bad))
    bad2 = list(frames); bad2[0] = "XYZ" + bad2[0][3:]
    check("rejects wrong magic", rejects(bad2))
    check("rejects empty input", rejects([]))

    print("\n[7] RAID 6 parity on real samples")
    import itertools
    for name, cmds in corpus.items():
        enc = m.encode_image(cmds)
        sent = enc.transmit_frames
        check(f"{name} carries P and Q", len(enc.parity_frames) == m.PARITY_FRAMES)
        check(f"{name} parity fits a message", all(len(f) <= m.MESSAGE_LEN for f in sent))
        reference = [c.to_json() for c in m.decode_frames(enc.frames)]
        wrong = 0
        for lost in itertools.chain(itertools.combinations(range(len(sent)), 1),
                                    itertools.combinations(range(len(sent)), 2)):
            got = m.decode_frames([f for i, f in enumerate(sent) if i not in lost])
            wrong += [c.to_json() for c in got] != reference
        check(f"{name} survives every 1- and 2-message loss", wrong == 0, f"{wrong} wrong")
    check("parity=False sends data only", m.encode_image(sample, parity=False).parity_frames == [])
    lines = m.encode_image(sample).transmit_frames
    (tmp / "lost2.mci").write_text("\n".join(lines[1:-1]) + "\n")
    r = run(["MCoreIMG-Reconstructor.py", str(tmp / "lost2.mci"), "--no-render", "--no-open"])
    check("reconstructor rebuilds two lost messages", r.returncode == 0 and "rebuilt part(s) 1" in r.stdout,
          (r.stdout + r.stderr)[-200:])
    (tmp / "lost3.mci").write_text("\n".join(lines[2:-1]) + "\n")
    r = run(["MCoreIMG-Reconstructor.py", str(tmp / "lost3.mci"), "--no-render", "--no-open"])
    check("reconstructor refuses three lost messages", r.returncode == 2)

    print("\n[8] Several images on one channel")
    import random
    rng = random.Random(77)
    encoded_all = {name: m.encode_image(cmds) for name, cmds in corpus.items()}
    truth = {e.image_id: [c.to_json() for c in m.decode_frames(e.frames)] for e in encoded_all.values()}
    check("sample images have distinct ids", len(truth) == len(encoded_all))
    wrong = incomplete = 0
    for _ in range(30):
        stream = []
        for e in encoded_all.values():
            sent = e.transmit_frames
            lost = set(rng.sample(range(len(sent)), rng.choice([0, 1, 2])))
            stream += [f for i, f in enumerate(sent) if i not in lost]
        stream += rng.sample(stream, 4) + ["<N9AJC> 73", "MCI garbage"]
        rng.shuffle(stream)
        images, pending, _ = m.sort_and_decode(stream)
        wrong += any([c.to_json() for c in im.commands] != truth[im.image_id] for im in images)
        incomplete += len(images) != len(encoded_all) or bool(pending)
    check("30 interleaved streams: every image decoded", incomplete == 0, f"{incomplete} streams short")
    check("30 interleaved streams: no image decoded wrongly", wrong == 0)
    log = []
    for e in encoded_all.values():
        log += e.transmit_frames[1:]
    rng.shuffle(log)
    (tmp / "channel.log").write_text("\n".join("<N9AJC> " + f for f in log) + "\n")
    r = run(["MCoreIMG-Reconstructor.py", str(tmp / "channel.log"), "-o", str(tmp / "ch.png"), "--no-open"])
    outputs = sorted(p.name for p in tmp.glob("ch-*.png"))
    check("reconstructor writes one PNG per image", r.returncode == 0 and len(outputs) == len(encoded_all),
          (r.stdout + r.stderr)[-200:])
    check("PNG names carry the image id", all(any(i in name for name in outputs) for i in truth))

    print("\n[9] Mismatched pairing")
    fake = tmp / "MCoreIMG-compression.py"
    fake.write_text(Path(ROOT, "MCoreIMG-compression.py").read_text()
                    .replace("PROTOCOL_VERSION = 7", "PROTOCOL_VERSION = 6", 1))
    r = run(["MCoreIMG-Reconstructor.py", str(tmp / "t.mci"), "--compression", str(fake),
             "--no-render", "--no-open"])
    check("mismatched codec refused", r.returncode == 2)

    print("\n" + "=" * 58)
    passed = sum(1 for ok in results if ok)
    print(f"{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
