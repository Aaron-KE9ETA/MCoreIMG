#!/usr/bin/env python3
"""Check the codec still reproduces the frozen parity fixtures exactly.

The fixtures are the contract a port is verified against, so the reference
must not drift from them. A failure here means the parity layer changed: that
is a wire-format change, and the fixtures and every port must move together.

This file is also the template for a port's own verifier: same inputs, same
expected outputs, zero mismatches.

    python tests/test_parity_fixtures.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
from harness import ROOT, load_codec


def main():
    m = load_codec()
    with open(os.path.join(ROOT, "tests", "fixtures", "parity_fixtures.json"), encoding="ascii") as fh:
        fixtures = json.load(fh)
    field = fixtures["field"]
    mismatches = []
    if field["coef13"] != m._COEF13 or field["coef49"] != m._COEF49:
        mismatches.append("field coefficient tables changed")
    checked = 0
    for case in fixtures["cases"]:
        data = case["data_frames"]
        if m.build_parity_frames(data) != case["parity_frames"]:
            mismatches.append(f"{case['name']}: parity frames differ")
        sent = data + case["parity_frames"]
        for lost in case["loss_patterns"]:
            got = m.reassemble_frames([f for i, f in enumerate(sent) if i not in lost]).frames
            checked += 1
            if got != data:
                mismatches.append(f"{case['name']}: wrong reassembly with {lost} lost")
    with open(os.path.join(ROOT, "tests", "fixtures", "sorter_fixtures.json"), encoding="ascii") as fh:
        sorter_fixtures = json.load(fh)
    completions = 0
    for number, stream in enumerate(sorter_fixtures["streams"]):
        sorter = m.FrameSorter()
        events = []
        for arrival, frame in enumerate(stream["frames"]):
            for image in sorter.add(frame, now=float(arrival)):
                events.append({"arrival": arrival, "image_id": image.image_id, "k": image.k,
                               "recovered": image.recovered, "data_frames": image.frames})
        completions += len(events)
        if events != stream["completions"]:
            mismatches.append(f"sorter stream {number}: completions differ")
        if [st.image_id for st in sorter.pending()] != stream["pending_at_end"]:
            mismatches.append(f"sorter stream {number}: pending sets differ")
    if mismatches:
        print(f"FAIL: {len(mismatches)} mismatch(es)")
        for line in mismatches[:20]:
            print("  " + line)
        return 1
    print(f"PASS: {len(fixtures['cases'])} parity cases, {checked} loss patterns; "
          f"{len(sorter_fixtures['streams'])} sorter streams, {completions} completions; 0 mismatches")
    return 0


if __name__ == "__main__":
    sys.exit(main())
