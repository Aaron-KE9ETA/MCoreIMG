# MCoreIMG — Announcement Briefing

**Purpose of this document.** Everything needed to write an accurate public
announcement about MCoreIMG, including the parts that must not be overstated
and the network-safety posture that should accompany any release.

**Audience for the announcement.** MeshCore operators, amateur radio operators,
LoRa mesh hobbyists, and people interested in extreme-constraint codec design.

---

## 1. One-paragraph summary

MCoreIMG encodes vector artwork into no more than **ten 120-character text
messages**, plus two parity messages, so it can travel over a MeshCore channel, a LoRa mesh network that carries
plain strings rather than binary. It imports a practical subset of SVG,
combines it with compact radio-oriented drawing primitives, compresses the
result with a purpose-built codec, and reassembles it on the far side. A
720 × 480 traced portrait with 64 shapes fits in 1,083 characters, and
survives the loss of any two of its twelve messages. Codec work has
reached the point of diminishing returns, and the project is now moving from
protocol development into **Alpha**.

---

## 2. What it is, and what it is not

**It is:**

- A vector image codec designed around a hard 1,120-character budget.
- A GUI authoring tool (Constructor) and a receiving tool (Reconstructor).
- An experiment in what is achievable at the extreme end of bandwidth scarcity.

**It is not:**

- **Not Meshtastic.** MeshCore is a different network with different routing.
  Do not describe MCoreIMG as a Meshtastic feature or imply compatibility.
- **Not a TinyVG implementation.** TinyVG was an architectural reference for
  reducing SVG to a palette plus an ordered command stream. MCoreIMG is not
  TinyVG-compatible and does not read or write TinyVG files.
- **Not a photo transport.** It carries vector shapes. Photographs must be
  posterized or traced to vectors first, and the result is a stylized image.
- **Not production-ready.** See §4.
- **Not a general-purpose image format.** Every design decision is subordinate
  to the ten-message envelope.

---

## 3. Why it exists

LoRa mesh networks are built for short text. Bandwidth is measured in bytes per
transmission and airtime is a shared, finite resource that every node in range
pays for. Sending an image over such a network is ordinarily out of the
question.

The interesting question is not "can we send images" — it is "how much visual
information can survive a 1,120-character budget, and what does a codec look
like when that budget is the only thing that matters." MCoreIMG is an answer to
the second question.

Legitimate uses are narrow and deliberate: a hand-drawn sketch map to a
meeting point, an antenna orientation diagram, a simple schematic, a site
layout. Anything that would otherwise be a long and ambiguous text description.

---

## 4. Status and versioning

- **Status: entering Alpha development.** Compression and protocol work has
  concluded (see 9.1); the effort now shifts to hardening, usability, and the
  network safeguards in section 8.
- Interfaces and file formats remain subject to change, though the wire
  protocol is expected to settle now that codec work has stopped.
- **Current wire protocol: version 6.**
- **No backward compatibility.** Protocol 7 changed the frame header so that
  messages from many images can share one channel and be sorted back into
  per-image sets; it does not decode protocol 6 frames, and no compatibility
  shim is provided. Each Constructor must be paired with its matching codec and
  Reconstructor; the tools detect and refuse mismatched pairs and report every
  build string involved.
- **Not recommended for use on shared production mesh infrastructure** until
  the safeguards in §8 are implemented and, where noted, supported upstream.

---

## 5. Architecture

Four Python modules in a strict dependency chain. Each layer may import the
ones above it and never the ones below.

| Module | Lines | Role |
|---|---|---|
| `MCoreIMG-model.py` | 954 | Shared vocabulary: opcodes, commands, geometry, colour |
| `MCoreIMG-compression.py` | 2,805 | The codec: geometry pipeline, entropy coding, framing |
| `MCoreIMG-Constructor.py` | 2,450 | SVG import, rendering, editor GUI |
| `MCoreIMG-Reconstructor.py` | 824 | Frame decoding, PNG output, JSON export |

Requirements: Python 3.10+, Tkinter for the GUI, Pillow for rendering. The
Reconstructor can decode and export JSON headless without Pillow or a display.

**A point worth making in the announcement:** compression lives in exactly one
file. Changing how images are packed means editing `MCoreIMG-compression.py`
and nothing else. That was a deliberate restructuring — an earlier build was
two files with several historical implementation layers stacked on top of each
other, and the receiver carried roughly seven hundred lines of reflection
purely to cope with the transmitter having no stable API.

---

## 6. Transport profile

| Property | Value |
|---|---|
| Messages per image | 10 data maximum, plus 2 parity |
| Characters per message | 120 (MeshCore channel limit) |
| Frame header | 8 characters |
| Payload per frame | 112 characters |
| **Total payload** | **1,120 characters** |
| Canvas | 720 × 480 |
| Palette | 32 entries, RGB565 + 4-bit alpha |
| Commands | 2,048 maximum |
| Compact primitives | 12 |

The frame header is 8 Base62 characters: 3 magic, 1 protocol, 3 image id, and
1 part descriptor that packs the frame index, a final-frame flag, and the
coding mode into a single character.

There is **no per-frame checksum** — MeshCore already guarantees the integrity
of a delivered message, so spending characters on a redundant CRC was waste.
A stream-level CRC-32 remains, because it catches what MeshCore cannot see:
frames from two different images with colliding identifiers, or a wrong set
pasted together by a human.

There is also no length field, because chunking fills every frame except the
last, making length derivable. Those two removals took the header from 15
characters to 8 and bought 70 characters of extra payload.

Payload is Base91-encoded because MeshCore carries strings, not binary. That
costs roughly 1.22× expansion — a binary-safe transport would recover about 18%
immediately, but it is not available.

---

## 7. How the compression works

Worth describing at a high level; the detail is in `Compression_readme.md`.

**Geometry simplification.** Because transport coordinates are integers, any
vertex within half a pixel of the line between its neighbours cannot change the
decoded image, so removing it is lossless *at transport precision*. On densely
traced artwork this removes 80–90% of vertices.

**Per-object rate–distortion search.** A single global simplification tolerance
has to be set for the most delicate object in the image, wasting bits on every
large smooth contour. Tolerance is chosen per object against a budget that
scales with feature size. Text, hairline strokes, features under 24 pixels, and
sharp corners are protected explicitly.

**Shape recognition.** A traced circle or rectangle collapses from hundreds of
vertices to a handful of numbers.

**Local-space SVG groups.** Geometry is stored in a stable local coordinate box
with placement carried in a fixed-width transform. The same artwork costs the
same number of bits at 100%, 50%, or 10% display scale, and a duplicated SVG
reuses the definition.

**Symmetry-aware repeats.** Repeated shapes are matched under the eight
symmetries of the square — the transforms that preserve integer coordinates, so
matches are exact. Four-way arrows, mirrored antenna elements and symmetric
logos cost one record plus a transform code.

**Predictive point coding.** Two predictors run in parallel — previous point,
and linear extrapolation that tracks curves. Both ends score them from decoded
history and pick the same one, so selection costs no bits.

**Adaptive entropy coding.** A binary range coder models flags, record tags,
and Exp-Golomb prefixes. Because it has fixed overhead and loses on very small
images, every image is coded both ways and the smaller wins.

**Primitive pricing.** Compact primitives (Yagi, dish, moon, radio waves and so
on) are measured against their generic vector expansion in context and used
only when strictly smaller. The same primitive can win in one image and lose in
another.

---

## 8. Mesh safeguards

**This section matters more than the compression numbers and should not be
omitted from the announcement.**

### 8.1 The honest framing

A technically valid MCoreIMG frame set can still be an antisocial
transmission. Ten messages is ten messages: every repeater in range spends
airtime forwarding them, and on a flood-routed network that cost multiplies
across the mesh. The tool being correct does not make the transmission
appropriate.

The project's position should be stated plainly: **MCoreIMG is capable of
harming a shared mesh, and the burden is on the sender and on the tooling to
prevent that.**

### 8.2 The right cost metric

Message count is the wrong unit. **Airtime is what a mesh actually spends.**
The same ten messages cost wildly different amounts depending on spreading
factor and bandwidth — potentially seconds each at high spreading factors, and
that airtime is paid again by every repeater that forwards them. Wall-clock
spacing between transmissions is likewise the wrong safety metric; a sender can
space transmissions politely and still saturate a channel.

Any budgeting, throttling, or operator-facing warning should be expressed in
**estimated time-on-air**, computed from the actual radio parameters, not in
message counts.

### 8.3 Implemented today

- **The hard ten-message ceiling.** The encoder will not exceed it. An image
  that does not fit is reported as not fitting rather than silently split.
- **Preflight visibility.** The Constructor shows the live frame count and
  payload size while editing, so the cost is visible before transmission.
- **Loss tolerance without retransmission.** Two parity messages let the
  receiver rebuild any two lost messages, so a lossy link does not have to mean
  re-sending. This is a trade, and should be described as one: it costs two
  messages of airtime on every image (+20% on a full ten-frame image), in
  exchange for fewer retries when messages go missing. Whether that is a net
  saving depends on the link's loss rate, which has not been measured.
- **Preview matches transmission.** The editor previews the decoded command
  stream, so an operator is never surprised by what arrives.
- **Documented operating guidance** shipped with the project.

### 8.4 Planned, sender-side

- **Airtime estimation and display.** Show estimated time-on-air from
  spreading factor, bandwidth and coding rate before sending, not message
  count.
- **Airtime budgeting with cooldowns.** Enforce a rolling airtime budget with
  a mandatory quiet period after an image, sized by what the image actually
  cost.
- **Regional duty-cycle awareness.** Respect regulatory limits by region, and
  refuse to transmit when doing so would breach them.
- **Direct routing preference.** Prefer a direct path to a specific recipient
  over flooding the mesh. Flood routing is what makes bulk transfer harmful.
- **Flood-fallback detection and abort.** If a direct path goes stale
  mid-transfer and frames begin falling back to flood, abort rather than let
  per-frame retries cascade into repeated full-mesh floods. This is the
  critical failure mode for any bulk transfer and deserves explicit mention.
- **Bounded, per-frame retries.** Never retransmit a whole image
  automatically; retry only missing parts, with a hard cap.
- **Opt-in receiving.** Images should be requested or accepted, not pushed at
  a network unprompted.

### 8.5 Requires upstream MeshCore support

This is the part the announcement should be candid about.

**Sender-side voluntary rules are not sufficient for community trust.** A
repeater operator cannot verify that a sender is following them, and cannot
refuse traffic they cannot identify. Every safeguard above is something a
modified or careless client can simply skip.

The meaningful fix is **an allocated payload identifier for bulk/image
traffic**, so that:

- repeater operators can rate-limit, deprioritize, or refuse image traffic on
  their own infrastructure;
- network operators can measure how much of their airtime it consumes;
- participation becomes an explicit choice by each operator rather than
  something imposed on them by senders.

This requires changes to MeshCore firmware, not just to MCoreIMG. **It is not
implemented, and the announcement should not imply otherwise.** Engagement with
MeshCore maintainers and the operator community is an open action item, and
community input on the identifier's design is genuinely wanted.

### 8.6 Operator guidance to include

- Follow local regulations, band plans, and network conventions first.
- Treat image transmission as occasional and deliberate, never routine or
  automated.
- Ask before sending images on someone else's infrastructure.
- Prefer direct routing to a known recipient over flooding.
- Avoid peak network usage.
- Amateur radio operators: content must comply with licence conditions,
  including prohibitions on encryption and on obscuring meaning.

---

## 9. Measured performance

All figures are from the project's real test files, not synthetic benchmarks.

| Test image | Shapes | Payload | Frames | Colours |
|---|---|---|---|---|
| Traced portrait (Atassi) | 64 | 1,083 chars | 10/10 | 6 |
| Vector cart illustration | 25 | 638 chars | 6/10 | 9 |
| Traced portrait (Aflaq/Jadid) | 97 | 1,334 chars | does not fit (needs 12) | 6 |

The third is included deliberately: at 120-character channel messages the
densest test portrait no longer fits, and the honest framing is that MCoreIMG
suits simple-to-moderate artwork, not every traced image.

Each is sent with two parity messages and survives the loss of any two.

Encode time ranges from about 80 ms to roughly 3 seconds depending on
complexity, on a desktop CPU.

### 9.1 Payload reduction has reached its reasonable limit

This should be stated as a deliberate conclusion, not left as an omission.

Successive rounds of codec work produced large early gains and then flattened.
The most recent optimisation round -- per-object rate-distortion tolerance
search, shape recognition, and perceptual palette merging -- delivered about
**0.14% on real traced artwork**, having looked like roughly 20% on synthetic
content built to exercise those very features.

Two further well-motivated ideas were implemented in full, measured, and then
removed:

- **Cubic Bezier refitting.** A cubic segment costs three points, while
  Douglas-Peucker at the same tolerance retains fewer vertices overall, and the
  predictive point coder handles consecutive polyline vertices better than it
  handles control points. Measured -0.1% payload for +26% encode time.
- **Style-run reordering.** Grouping same-styled shapes where draw order
  permitted did work -- style runs fell from 97 to 64, with a byte-identical
  render -- but payload rose 0.1-0.4%, because scattering the geometry cost
  more in coordinate residuals than it saved in paint flags.

What remains on the table is known and bounded:

- A **multi-subpath record** carrying several outlines under one style header
  would recover roughly 9% of a traced portrait, since about a third of such a
  stream is per-record overhead. It is a wire-format change.
- A **binary-safe transport** would recover roughly 18% by removing Base91
  expansion. MeshCore carries strings, so this is not available.

Neither justifies further format churn against the value of a stable protocol
and a usable tool. **Compression is done; Alpha begins.** The judgement being
made is that the next meaningful improvements to this project are reliability,
usability, and network citizenship -- not bits.

**Be careful with compression percentages.** Improvements measured on synthetic
content did not survive contact with real tracer output — a benchmark built to
exercise the features being written showed roughly 20% gains, while the same
changes delivered about 0.1% on real traced portraits. If the announcement
quotes a compression improvement, it should quote one measured on real files
and say which. Prefer absolute results ("64 shapes in 1,083 characters") over
relative ones.

---

## 10. Verification posture

Useful for credibility, and honest about what is and is not covered.

- Both tools ship self-tests (`--self-test`).
- Round-trip fixtures assert the decoder reproduces exactly what the encoder
  promised to send.
- Raster fixtures pin rendered output.
- A writer/reader context-symmetry checker exists specifically because an
  adaptive entropy coder fails silently when the two sides disagree about a
  probability model — raw mode keeps working, so only entropy-coded images
  corrupt.
- Cross-module integration checks cover protocol pairing, corruption
  rejection, determinism, and scale independence.
- **Not covered:** the GUI has no automated test coverage, because it needs a
  display. Interactive behaviour is verified by hand.

---

## 11. Accuracy guardrails for the announcement

Things that would be wrong to say:

- ❌ "Send photos over LoRa." It sends vector shapes; photos must be traced.
- ❌ "Works with Meshtastic." Different network.
- ❌ "TinyVG-compatible." Architectural reference only.
- ❌ "Backward compatible" or "upgrade path from v5." Neither exists.
- ❌ "Safe for the mesh" or "mesh-friendly." The safeguards that would justify
  that claim are largely unimplemented, and the most important one needs
  upstream firmware support.
- ❌ Any specific compression percentage without naming the file it was
  measured on.
- ❌ "Production ready", "stable", or "1.0". Alpha is none of these.
- ❌ "Survives packet loss" without the limit. Parity rebuilds at most two lost
  messages per image; a third loss means the image does not arrive. Nor does
  parity reduce airtime — it adds two messages.
- ❌ "Fully optimised" or "maximally compressed." The claim is that further
  reduction is not *worth* its cost, not that none remains; 9.1 names what is
  still theoretically available.

Things that are accurate and worth saying:

- ✅ "A 64-shape traced portrait in 1,083 characters, across ten channel messages."
- ✅ "Two parity messages let any two of an image's messages be lost, RAID 6
  style." 
- ✅ "Entering Alpha; compression work has concluded and the wire protocol is
  expected to settle."
- ✅ "Further payload reduction is possible but no longer worth the format
  churn."
- ✅ "Compression lives in a single file by design."
- ✅ "Airtime, not message count, is the cost that matters."
- ✅ "Repeater-side control needs protocol support that does not exist yet."

---

## 12. Suggested tone

Understated and technically candid. The interesting story is the engineering
problem — what a codec looks like when a 1,120-character budget is the only
constraint that matters — not a claim to have solved image transmission over
LoRa.

The safeguards section should read as genuine caution rather than a
disclaimer. The most credible thing the project can say is that it knows
exactly how it could be misused, has thought carefully about the mitigations,
and is explicit that the most important one is not in its own hands.

---

## 13. Open questions worth raising publicly

- What identifier scheme would MeshCore maintainers and repeater operators
  want for bulk/image traffic?
- What airtime budget per node per hour would operators consider acceptable?
- Should image traffic be opt-in at the repeater level by default?
- Are there regional or band-specific constraints the project has not
  accounted for?

Community answers to these would shape the roadmap more than any further
compression work -- which is precisely why codec development has been closed
out and Alpha opened. With the format settling, the questions that matter now
are about how this behaves as a participant on someone else's network.
