# MCoreIMG

Compact vector image transmission over MeshCore.

MCoreIMG encodes vector artwork into no more than **ten 120-character MeshCore channel
messages**. It imports a practical SVG subset, combines it with compact
radio-oriented drawing primitives, and compresses the result into a text-safe
transport that survives ordinary chat relays.

> **Protocol:** MCoreIMG v7
> **Feature signature:** `PROTO7|LOCALSPACE|HYBRID|PRIMITIVES|GROUPCOPY|ALPHA|UNDO|10MSG|RAID6|MULTIIMAGE`
> **Status:** pre-alpha

---

## Repository layout

```
MCoreIMG-model.py            shared vocabulary, no dependencies
MCoreIMG-compression.py      the codec
MCoreIMG-Constructor.py      authoring GUI
MCoreIMG-Reconstructor.py    receiving tool
docs/                        per-module documentation and architecture
samples/                     real test artwork used for benchmarking
tools/                       benchmark and codec verification
tests/                       self-test runner and integration suite
```

The four modules must stay in one directory: each finds its siblings by path.

```bash
python tests/run_all.py      # every check
python tools/measure.py      # benchmark against samples/
```

## Modules

The project is four files in a strict dependency chain. Each layer may import
the ones above it and never the ones below.

| Module | Role | Imports | Docs |
|---|---|---|---|
| `MCoreIMG-model.py` | Shared vocabulary: opcodes, commands, geometry, colour | stdlib only | [Model_readme.md](docs/Model_readme.md) |
| `MCoreIMG-compression.py` | Bitstream codec, record selection, MeshCore framing | model | [Compression_readme.md](docs/Compression_readme.md) |
| `MCoreIMG-Constructor.py` | SVG import, rendering, editor GUI | model, compression | [Constructor_readme.md](docs/Constructor_readme.md) |
| `MCoreIMG-Reconstructor.py` | Frame decoding, PNG output, JSON export | model, compression, constructor | [Reconstructor_readme.md](docs/Reconstructor_readme.md) |

Design rationale, layering rules, and refactor history are in
[Architecture.md](docs/Architecture.md).

```
MCoreIMG-model.py            no dependencies
        |
MCoreIMG-compression.py      transport codec
        |
MCoreIMG-Constructor.py      authoring
        |
MCoreIMG-Reconstructor.py    receiving
```

### Which file do I edit?

| Change | File |
|---|---|
| Compression scheme, record types, bit layout, framing | `MCoreIMG-compression.py` |
| New opcode, new primitive, geometry or colour rules | `MCoreIMG-model.py` (then teach the codec to carry it) |
| SVG parsing, rendering, editor behaviour | `MCoreIMG-Constructor.py` |
| Decoding workflow, output formats, CLI | `MCoreIMG-Reconstructor.py` |

Compression is the single file to touch when changing how images are packed.
That is the point of the split.

---

## Requirements

- Python 3.10 or newer
- Tkinter/Tk — required by the Constructor GUI; the Reconstructor needs it
  only for the interactive file chooser
- Pillow — required for preview rendering and PNG export

### Arch Linux

```bash
sudo pacman -S --needed python tk python-pillow
```

### Other environments

Tkinter normally ships with the operating system. Pillow installs with:

```bash
python -m pip install Pillow
```

---

## File layout

Keep all four modules in one directory. The Constructor finds the codec beside
itself; the codec finds the model beside itself; the Reconstructor finds both.

```
mcoreimg/
├── MCoreIMG-model.py
├── MCoreIMG-compression.py
├── MCoreIMG-Constructor.py
└── MCoreIMG-Reconstructor.py
```

Each lookup can be overridden on the command line if you keep builds elsewhere.

---

## Quick start

### Authoring

```bash
python MCoreIMG-Constructor.py
```

Import SVG, arrange it, watch the `n/10` message counter, then export `.mci`
frames.

### Receiving

```bash
python MCoreIMG-Reconstructor.py received.mci
```

Decodes, validates, renders a PNG, and opens it. A saved channel log holding
several images works the same way: each complete image is written as its own
PNG, named with its image id, and incomplete ones are listed.

### Verifying an installation

```bash
python MCoreIMG-Constructor.py --version
python MCoreIMG-Constructor.py --self-test
python MCoreIMG-Reconstructor.py --self-test
```

`--version` prints the whole chain, so a mismatched set is visible immediately:

```text
2026.10.17-svg-v7.0-MODULAR-MULTIIMAGE-10+2MSG
PROTO7|LOCALSPACE|HYBRID|PRIMITIVES|GROUPCOPY|ALPHA|UNDO|10MSG|RAID6|MULTIIMAGE
protocol=7 messages=10 source_version=6
codec=2026.10.17-compression-v7.0-MULTIIMAGE
codec_path=/path/to/MCoreIMG-compression.py
model=2026.08.05-model-v6.0-MODULAR
model_path=/path/to/MCoreIMG-model.py
```

---

## Transport profile

| Property | Value |
|---|---|
| Messages per image | 10 data maximum, plus 2 parity |
| Characters per message | 120, the MeshCore channel limit |
| Frame header | 8 characters |
| Payload per frame | 112 characters |
| Total payload | 1,120 Base91 characters |
| Canvas | 720 × 480 |
| Palette | 32 entries, RGB565 + 4-bit alpha |
| Commands | 2,048 maximum after expansion |

Each frame carries an image id and a single part descriptor. The 4-character
image id ties every message of an image together, so frames from several images
interleaved on one channel are sorted back into sets and each image decodes on
its own; see
[Compression_readme.md](docs/Compression_readme.md#multi-image-receive). There is no per-frame CRC — MeshCore already guarantees message
integrity — and no length field, because chunking fills every frame except the
last. The reassembled stream still carries a CRC-32, which catches the
mis-assembly MeshCore cannot see.

**Parity.** Two extra messages, P and Q, let the receiver rebuild any two lost
messages out of the k + 2 sent, in the manner of RAID 6. They use the same
91-character alphabet as the data, so a parity frame is never longer than a
data frame, and the data frames themselves are unchanged. The cost is airtime:
two more messages, +20% on a full 10-frame image. See
[Compression_readme.md](docs/Compression_readme.md#erasure-parity-raid-6).

---

## How compression works

A short tour. [Compression_readme.md](docs/Compression_readme.md) has the detail.

**Geometry simplification.** Vertices that cannot survive integer rounding, or
that sit within half a pixel of the line between their neighbours, are dropped
before encoding. This is lossless at transport precision and routinely removes
80–90% of the vertices in traced artwork.

**Entropy coding.** An adaptive binary range coder models flags, record tags,
and Exp-Golomb prefixes. Each image is coded both raw and entropy-coded and the
smaller wins, so the coder's fixed overhead can never make a small image worse.

**Palette.** Every colour is quantized to RGB565 plus 4-bit alpha and collected
into an ordered table. Commands then reference palette indices.

**Stateful coding.** Point and style state are tracked per opcode. Coordinates
are coded as residuals against a prediction, falling back to absolute only when
that is cheaper. Two predictors run in parallel — "same as the last point" and
a linear extrapolation that tracks curves — and both ends score them from
decoded history, so choosing between them costs no bits.

**Repeat detection.** The encoder looks for repeated single commands and
contiguous runs, and emits a back-reference plus a delta rather than the
geometry again. Repeats are matched under the eight symmetries of the square,
so rotated and mirrored copies — four-way arrows, mirrored antenna elements,
symmetric logos — are caught as well as plain translations.

**Local-space SVG groups.** An imported SVG is normalized into a stable local
coordinate box, transmitted once, and placed with a fixed-width transform.
Moving or resizing the artwork changes only the transform, so the same drawing
costs the same number of bits at 100%, 50%, or 10% display scale. Duplicated
SVGs reuse the definition and send only a new transform.

**Primitive pricing.** Compact primitives such as Yagi, Dish, and Moon are
measured against their generic vector expansion in context. The primitive is
used only when it is strictly smaller.

**Precision search.** `encode_image` walks a ladder of local-coordinate extents
from 255 down to 32 and returns the highest precision that still fits the
ten-message budget.

---

## Record types

| Tag | Name | Meaning |
|---|---|---|
| 0 | `REC_NORMAL` | A fully specified command |
| 1 | `REC_SINGLE_REPEAT` | Re-emit one earlier command at a delta |
| 2 | `REC_GROUP_REPEAT` | Re-emit a contiguous run at a delta |
| 3 | `REC_TRANSFORM_GROUP` | A local-space SVG group: display box plus an inline definition or a back-reference |

Both repeat records carry an optional symmetry code (rotation and mirror), so
a repeat is a symmetry plus a translation rather than a translation alone.

---

## File formats

| Extension | Purpose | Transmitted |
|---|---|---|
| `.svg` / `.svgz` | Source artwork for import | no |
| `.mci.json` | Editable Constructor source | no |
| `.mci` | One MeshCore frame per line | yes |
| `.png` | Raster preview of the decoded image | no |

`.mci.json` preserves command order, styles, primitive parameters, document
transforms, warnings, and editor grouping. It is not the radio transport format
and may evolve independently of the protocol version.

---

## Compatibility

The Constructor emits protocol v7. Protocol 7 changed the frame header — a
4-character image id, and no version field — so that messages from many images
can share a channel and be sorted back into sets. Receivers older than
protocol 7 will not decode v7 frames, and v7 receivers do not decode v6 frames.
Pair each Constructor with its matching codec and Reconstructor.

Editable `.mci.json` source files are not tied to a wire protocol and still
load.

The current build detects mismatches directly. Protocol numbers are compared
between the input, the codec, and the renderer, and every failure names the
files involved and their build strings.

---

## Measured results

Against the real artwork in `samples/`:

| Sample | Shapes | Payload | Data frames | Sent with parity | Colours |
|---|---|---|---|---|---|
| Traced portrait (Atassi) | 64 | 1,083 chars | 10/10 | 12 | 6 |
| Vector cart illustration | 25 | 638 chars | 6/10 | 8 | 9 |
| Traced portrait (Aflaq/Jadid) | 97 | 1,334 chars | needs 12 | — | 6 |

The two that fit survive the loss of any two of their messages. The Aflaq
portrait no longer fits now that channel messages are 120 characters: even at
the coarsest local precision it needs 12 data frames, and coarser precision
does not help (extent 12 still gives 1,267 characters). It is kept in
`samples/` as the over-budget case; the encoder reports it as not fitting and
emits nothing.

Payload reduction has reached its reasonable limit; see the "measured and
removed" sections in `MCoreIMG-compression.py` for ideas that were built,
benchmarked, and discarded, and why. Benchmark any future change against
`samples/`, never against synthetic content.

## Known limitations

- The targeted use is a MeshCore channel, where messages are 120 characters
  (direct messages allow 150). That cut the payload budget by 21%, from 1,420
  to 1,120 characters, and the densest sample no longer fits ten frames.
- The Atassi portrait fits only by dropping local precision to extent 80, and
  sits at exactly 10/10 frames, so there is no headroom.
- The precision ladder can drop local-space groups to a coarse extent to make
  an image fit, which is visible as vertex movement on dense artwork.
- The per-object tolerance search budgets by on-canvas feature size, so display
  scale affects payload by up to about a percent. Local-space groups keep the
  geometry cost itself scale-independent.
- Encode time reaches a few seconds on the densest sample, because the
  precision ladder codes the stream twice per rung to choose raw versus
  entropy coding.
- The GUI has no automated test coverage.
- Parity adds two messages of airtime to every image. It is on by default;
  `encode_image(..., parity=False)` omits it, but the GUI has no toggle yet.
- Parity recovers *lost* messages. It does not locate a message that arrives
  corrupted; the stream CRC-32 detects that, and the set is refused.

## Development rules

Before committing protocol or editor changes:

1. Run `--version` on both tools and confirm protocol 7 with the expected
   feature signature and matching model/codec builds.
2. Run `--self-test` on both tools.
3. Import a normal SVG and a multi-SVG document.
4. Verify dragging and scaling operate on the intended complete group.
5. Verify the payload stays stable when only display scale changes.
6. Test a translucent overlap image and compare preview against exported PNG.
7. Draw at least one compact primitive and check the primitive/vector
   statistics.
8. Duplicate an imported SVG and confirm local-definition reuse.
9. Import an oversized SVG and confirm Undo restores the previous document.
10. Decode the exported frames with the paired Reconstructor.

### Changing the compression scheme

Any change to a writer must be mirrored in its reader. A change that alters
emitted bits for unchanged input is a **protocol change**: bump
`PROTOCOL_VERSION` and update both ends in the same commit.

Do not combine a structural cleanup with a protocol-format change. Those are two
separate review problems.

---

## TinyVG relationship

TinyVG was an architectural reference for reducing SVG into a deterministic
palette and ordered command stream. MCoreIMG is **not** a TinyVG implementation
or a TinyVG-compatible file format. It is optimized specifically for severe
MeshCore message limits, text-safe framing, repeated artwork, compact legacy
primitives, and radio-oriented reconstruction.

---

## Safety and operating considerations

MCoreIMG is designed for occasional, deliberate image transmission over
constrained radio networks. A technically valid frame set can still consume
shared airtime. Operators should follow local rules, network conventions, and
good amateur-radio practice when choosing when and how often to transmit
images.
