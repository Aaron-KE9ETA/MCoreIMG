#!/usr/bin/env python3
"""Run every check in the repository.

    python tests/run_all.py
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STEPS = [
    ("Constructor self-test", ["MCoreIMG-Constructor.py", "--self-test"]),
    ("Reconstructor self-test", ["MCoreIMG-Reconstructor.py", "--self-test"]),
    ("Entropy context symmetry", ["tools/ctxcheck.py"]),
    ("Integration", ["tests/test_integration.py"]),
    ("Port fixtures", ["tests/test_parity_fixtures.py"]),
    ("Benchmark", ["tools/measure.py"]),
]


def main():
    failures = []
    for label, args in STEPS:
        print(f"\n{'=' * 58}\n{label}\n{'=' * 58}")
        result = subprocess.run([sys.executable] + args, cwd=ROOT)
        if result.returncode != 0:
            failures.append(label)
    print(f"\n{'=' * 58}")
    if failures:
        print("FAILED: " + ", ".join(failures))
        return 1
    print(f"All {len(STEPS)} checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
