# MCoreIMG Compression

The transport codec. Everything that turns drawing commands into radio bytes
and back again.

`MCoreIMG-compression.py` owns geometry simplification, bit modelling, entropy
coding, record selection, palette assembly, local-space group planning, Base91
payload coding, and MeshCore framing. No other module writes a bit or chooses a
record type.

> **Build:** `2026.10.17-compression-v7.0-MULTIIMAGE`
> **Protocol:** 7
> **Depends on:** `MCoreIMG-model.py`

If you are changing how images are compressed, this is the only file you need
to edit.

---

## Public API

### Full pipeline

```python
encode_image(commands, parity=True) -> EncodedImage
```

Simplify, plan, compress, and frame. Searches the precision ladder for the
highest local-coordinate fidelity that fits ten messages, and chooses between
raw and entropy coding. When the image fits, adds the two RAID 6 parity frames;
`parity=False` sends the data frames alone. Send `encoded.transmit_frames`.

```python
decode_frames(frames) -> list[VectorCommand]
```

Validate the envelope, rebuild up to two missing frames from parity, check the
stream CRC, and decompress. Frames may arrive in any order, with duplicates.

```python
reassemble_frames(frames) -> Reassembly
build_parity_frames(data_frames) -> [P, Q]
```

The parity layer on its own. `Reassembly` carries the completed, in-order data
frames, which parts were rebuilt, `k`, the coding mode, and how many parity
frames arrived.

### Bitstream only

```python
encode_commands(commands, local_extent=LOCAL_GROUP_EXTENT)
    -> (payload_bytes, bit_count, metrics, palette)

decode_commands(data, mode=1) -> (list[VectorCommand], palette)
```

`mode` selects raw (`0`) or entropy-coded (`1`). Frames carry it in the header;
call `decode_commands` directly only with the mode reported in
`stats.coding_mode`.

### Encoder-side tools

`simplify_commands`, `apply_symmetry`, `geom_symmetry`, `build_palette`,
`geom_translation`.

### Framing primitives

`base91_encode`, `base91_decode`, `enc62`, `dec62` — exposed for frame-repair
tooling.

### Re-exports

Importing the codec yields the full model vocabulary as well: `VectorCommand`,
`PaintStyle`, all opcodes and primitives, geometry helpers, and colour
quantization.

---

## Stream layout

```
[4 bits]   protocol version
[ue]       palette_count - 1
[16 + 4 bits] * palette_count    RGB565 + 4-bit alpha
[ue]       command_count
record*
```

Every record opens with a two-bit tag:

| Tag | Name | Meaning |
|---|---|---|
| 0 | `REC_NORMAL` | A fully specified command |
| 1 | `REC_SINGLE_REPEAT` | Re-emit one earlier command under a symmetry and delta |
| 2 | `REC_GROUP_REPEAT` | Re-emit a contiguous run at a delta |
| 3 | `REC_TRANSFORM_GROUP` | A local-space SVG group |

The compressed stream is followed by a CRC-32, Base91-encoded, and split across
frames.

---

## Compression techniques

Roughly in the order the encoder applies them.

### Geometry simplification

Transport coordinates are integers. A vertex that rounds onto the same pixel as
its neighbour, or that sits within half a pixel of the line between them,
cannot change the decoded image — so removing it is **lossless at transport
precision**. No quality trade-off, no search, and the decoder is unaffected.

`SIMPLIFY_TOLERANCE` defaults to `0.5`, the lossless boundary. Raising it is not
a protocol change; it only trades fidelity for size.

This matters because coordinates dominate the payload, and real SVG — traced
logos, map exports, illustrator output — carries far more vertices than a
720 × 480 canvas can resolve. Measured on synthetic traced artwork:

| Input | Vertices removed | Payload | Max deviation |
|---|---|---|---|
| 400-point traced outline | 80% | −73% | 0.49 px |
| 1200-point traced outline | 93% | −91% | 0.48 px |
| Collinear axis-aligned outline | 83% | −69% | 0.00 px |

Structural minimums are always honoured: a polygon keeps three points and a
polyline two. Bézier control points are never dropped, because a control point
is structural rather than a sample — only maximal runs of `LineTo` are reduced.

### Palette

Every fill and stroke colour is quantized to RGB565 with 4-bit alpha and
collected into an ordered table, capped at 32 entries (`MAX_PALETTE`).

### Opcode-local state

Point and style state are tracked **per opcode**, not globally, because artwork
clusters by shape type. A rectangle following a run of ellipses still predicts
from the previous rectangle.

Normal records carry one-bit same-opcode and same-style shortcuts.

### Point prediction

Each point is coded as a residual against a prediction, or absolutely when that
is cheaper. Two predictors run in parallel:

- **first order** — the previous point for this opcode
- **second order** — linear extrapolation, `2·p[n-1] − p[n-2]`

Second order tracks flattened Béziers and traced outlines far better, because
those advance in a roughly constant direction.

**The choice costs no bits.** Both ends keep decayed absolute-error scores for
the two predictors, updated identically from decoded history, and use whichever
is currently winning. The codec follows the artwork instead of committing to one
predictor or spending a selector bit per point.

### Repeats under symmetry

When a command repeats an earlier one, the encoder emits a back-reference and a
delta instead of the geometry.

Matching is done under the **eight symmetries of the square** — four rotations
by 90°, each optionally mirrored. Those are exactly the transforms that map
integer coordinates to integer coordinates with no rounding, so a match is exact
rather than approximate. Arbitrary rotation and scaling would need tolerance
handling and are deliberately out of scope.

`REC_SINGLE_REPEAT` carries a flag saying "plain translation" and, when it is
not, a 3-bit symmetry code. With entropy coding that flag is strongly skewed and
costs a fraction of a bit, so plain translations are barely affected.

Rect and ellipse are transformed directly rather than through the generic matrix
path, because every symmetry maps an axis-aligned box to an axis-aligned box.
Keeping the opcode intact is what allows the repeat to match at all. Compact
primitives are excluded: their orientation lives in a geometry field rather than
in coordinates, so rotating one is not representable.

Measured on symmetric artwork:

| Artwork | Saving vs translation-only |
|---|---|
| One shape in four rotations | −32% |
| Mirrored pairs | −13% |
| Symmetric tiling | −18% |

`geom_translation` proves a plain translation by re-translating the earlier
command and requiring the geometry dictionaries to match exactly, so a
coincidental point-count match cannot produce a false positive. `geom_symmetry`
layers the symmetry search on top, trying identity first.

### Delta coding

Repeat deltas use signed Exp-Golomb (zigzag + `ue`), not Rice.

Repeat distances span the whole canvas: an adjacent copy is a few units away, a
mirrored one on the far side is several hundred. A fixed Rice parameter cannot
serve both — `k=2` spends over a hundred unary bits on a distance of 200, which
made every distant repeat lose to a full record. Exp-Golomb grows
logarithmically instead.

### Local-space SVG groups

A contiguous run of commands sharing an `editor_group` is normalized into a
stable local coordinate box and transmitted as:

```
fixed-width display box (x, y, width, height, local_width, local_height)
        +
either an inline local definition or a back-reference to an earlier one
```

The display box is 10 + 9 + 10 + 9 + 8 + 8 bits. Fixed width is deliberate:
moving or resizing a group changes the *values* but never the field *length*.
The same artwork therefore costs the same bits at 100%, 50%, or 10% display
scale, and duplicated SVGs reuse the definition.

### Primitive pricing

Compact primitives are simulated against their generic vector expansion using
live encoder state. The primitive is used only when it is **strictly smaller**,
so the same primitive can win in one image and lose in another.

### Precision ladder

```python
PRECISION_LADDER = (255, 224, 192, 160, 144, 128, 112, 96,
                    80, 72, 64, 56, 48, 40, 32)
```

`encode_image` encodes at each extent in turn and returns the first result that
fits ten messages. Images without eligible local groups skip the search. The
chosen precision depends on geometry complexity, never on displayed scale.

---

## Entropy coding

Protocol 6 replaces raw bit packing with an **adaptive binary range coder**
(LZMA-style). A flag that is 90% one value costs about 0.47 bits instead of 1.

Bits fall into two classes:

- **contexted** — skewed and worth modelling: record tags, opcodes, same-opcode
  and same-style flags, style flags, point mode flags, and the unary prefixes of
  Exp-Golomb and Rice codes. Each context adapts independently.
- **bypass** — near-uniform: absolute coordinate bits, palette indices, Rice
  remainders. Coded at a flat 1 bit so they cannot pollute the models.

Contexts are plain strings, so a new syntax element can be added without
renumbering a table. They are created on demand and start at p = 0.5.

### Why records are elements, not bits

The planner builds competing candidate records and splices the winner. An
adaptive coder cannot be spliced after the fact, because each bit's cost depends
on every bit before it.

So `BitWriter` records **syntax elements** with an estimated pre-entropy cost.
Splicing is list concatenation, planning compares `cost`, and entropy coding
happens once at the end over the final sequence. `cost` deliberately matches the
older raw-bit measure so representation choices stay stable.

### Dual mode

The range coder pays a fixed flush cost and needs data before its models are
worth anything, so it loses on very small images — up to +33% on a single
command.

`best_bytes()` therefore codes both ways and keeps the winner. **Protocol 6 is
never worse than protocol 5 on any image.** The cost is one extra encode pass
over a payload of at most 1,120 characters.

The mode flag rides free in the frame header. `stats.coding_mode` reports which
was used.

### Writer/reader symmetry is critical

If a writer and its reader disagree about which context a bit belongs to, **raw
mode still works** and only entropy-coded images corrupt. That makes the bug
easy to introduce and hard to spot — it surfaces as an `IndexError` or a
nonsense opcode far from its cause.

Every `w.bit(v, ctx)` must have a matching `r.bit(ctx)`. When adding a syntax
element, add its context to both sides in the same edit, then verify by
recording the encoder's context sequence and the decoder's and diffing them.
That trace is the only reliable way to locate a mismatch.

---

## MeshCore framing

### Envelope

| Property | Value |
|---|---|
| `MAX_MESSAGES` | 10 |
| `MESSAGE_LEN` | 120, the MeshCore channel limit |
| `FRAME_HEADER_LEN` | 8 |
| `FRAME_PAYLOAD_LEN` | 112 |
| `MAX_PAYLOAD_CHARS` | 1,120 |

### Header

8 characters, all Base62:

| Field | Width | Meaning |
|---|---|---|
| magic | 3 | `MCI`; also names the frame format (protocol 7) |
| image id | 4 | Ties every message of one image together |
| part | 1 | `index + 10·final + 20·mode` |

The part descriptor packs three things into one character — the frame index
(0–9), whether it is the final frame, and the coding mode — using 40 of the 62
available values.

**There is no version field.** The magic strings name the frame format, as
file magic does, and the codec version is also carried in the first four bits
of the stream. A future frame format changes the magic. Dropping the field is
what paid for the fourth image-id character without shrinking the payload.

**The image id ties a set together.** It is the stream's CRC-32 reduced to four
Base62 characters (14.8 million values), computed by `image_id_for(raw)`.
Because it is derived from content, identical images sent by different stations
produce identical frames that merge, and once a set is assembled the receiver
checks that the content actually hashes to the id it carries. A set mixed from
two images therefore fails that check even when the stream CRC alone would not
catch it.

**There is no per-frame CRC.** MeshCore already guarantees the integrity of a
delivered message, and the stream CRC-32 still catches what MeshCore cannot see:
frames from two images with colliding identifiers, or the wrong set pasted
together.

**There is no length field.** Chunking fills every frame except the last, so a
non-final frame is always exactly `MESSAGE_LEN` characters and the final frame
is simply what remains. A non-final frame that is not exactly full has been
truncated or concatenated, and is rejected.

Together these took the header from 15 characters to 8, worth 70 payload
characters across ten messages.

### Alphabets

`BASE91` excludes `"`, `'`, and `\` so frames survive text transports and shell
quoting. MeshCore carries strings rather than binary, so Base91's ~1.22×
expansion is the price of admission. `BASE62` carries the header fields.

### Validation

`decode_frames` rejects frames that are the wrong length, carry the wrong magic
or protocol, declare an out-of-range index, disagree about the coding mode,
carry a short non-final payload, come from a different image, conflict with a
duplicate, declare two different final frames, or fail the stream CRC-32. A gap
in the sequence is an error only when parity cannot fill it. Every failure
raises `FrameError`.

---

## Erasure parity (RAID 6)

Two extra messages, **P** and **Q**, follow the data frames. Any two of the
k + 2 messages may be lost — two data frames, two parity frames, or one of
each — and the receiver rebuilds the image exactly, as RAID 6 survives two
failed disks. A third loss is refused rather than mis-decoded.

The data frames are untouched, byte for byte. Parity is additive: a receiver
that ignores parity frames decodes the data frames as before.

### Why not GF(256)

Parity is normally computed over bytes in GF(256). That produces arbitrary
bytes, which MeshCore cannot carry; Base91-encoding them grows the parity by
about 23%, so a parity frame would need roughly 146 characters to protect 112,
and would not fit in a 120-character message.

### The alphabet-preserving code

The code works directly on Base91 symbols. Because **91 = 7 × 13**, the Chinese
remainder theorem makes every symbol exactly the pair (c mod 7, c mod 13), and
every such pair exactly one symbol. Parity runs separately in each residue and
recombines with `(78·r7 + 14·r13) mod 91`, so every parity symbol is again a
Base91 character and a parity frame is exactly as long as the data it protects.

P + Q RAID 6 needs a field whose multiplicative group has at least k distinct
elements, one Q coefficient per data frame:

| Residue | Field | Group order | Generator | Unit |
|---|---|---|---|---|
| mod 13 | GF(13) | 12 | 2 | one symbol |
| mod 7 | GF(49) = GF(7)[i], i² = −1 | 48 | 2 + i | adjacent symbol pair |

GF(7) alone has only six non-zero elements, too few for ten data frames, so
symbols are paired into GF(49). With distinct coefficients, every 2×2 system
the decoder can meet is non-singular, which is the whole RAID 6 guarantee. The
coefficient tables are asserted at import, so a changed generator cannot slip
through silently.

### Parity frame layout

| Field | Width | Meaning |
|---|---|---|
| magic | 3 | `MCP`, distinct so a parity frame is recognised before parsing |
| image id | 4 | Same as the data frames |
| descriptor | 1 | `which + 2·(k−1) + 20·mode`, which 0 = P, 1 = Q |
| symbols | L | L = longest data payload, rounded up to even |

With k > 1 the parity is 112 symbols and the frame is exactly 120 characters.
With k = 1 it matches the single data frame.

The descriptor carries **k and the coding mode**, so a receiver that has lost
the final data frame — or, when k = 1, every data frame — still knows how many
frames exist and how to decode them. It also gives a receive engine a
denominator before the final data frame arrives, which the data frames alone
never provide.

### The one thing parity cannot carry

A parity frame is already full, so the exact length of the final data frame is
not stored. When the final frame must be rebuilt, every position past its true
end rebuilds to the pad symbol, which narrows the candidates; each remaining
length is tried, and the one kept must be canonical Base91, pass the stream
CRC-32, and parse. More than one survivor raises an error rather than guessing.

### Cost

| | |
|---|---|
| Extra messages | 2, outside the ten-message data budget |
| Extra airtime | +2 messages: +20% on a 10-frame image, +33% on a 6-frame image |
| Encode time | under 1 ms |
| Worst-case recovery | about 100 ms, on a 10-frame image with the final frame lost |

### Verification

Measured with 120-character messages:

- Every 1- and 2-message loss on the samples that fit, in shuffled order with
  duplicates: 114 patterns, all exact.
- The final frame lost across 110 distinct final lengths (1–112) plus 42
  single-frame images: 566 decodes, all exact.
- Every 3-message loss refused: 276 of 276.
- `tests/fixtures/parity_fixtures.json`: 5 cases and 147 loss patterns for
  verifying a port, checked against the reference by
  `tests/test_parity_fixtures.py`.

---

## Multi-image receive

On a shared channel, messages from several images — several stations, or
several images from one station — arrive interleaved, out of order, with
duplicates, gaps, and unrelated chatter. `FrameSorter` takes them one at a time
and sorts them into per-image sets by image id, decoding each image as soon as
enough of its messages have arrived: all k data frames, or any k of the k + 2
with parity.

```python
sorter = FrameSorter()
for message in channel:                    # one received message at a time
    for image in sorter.add(message):      # images this message completed
        show(image.image_id, image.commands)
sorter.pending()                           # SetStatus for each incomplete set
sorter.expire(older_than=cutoff)           # drop sets not heard from since
```

`sort_and_decode(frames)` does the same for a batch, such as a saved channel
log, and returns `(images, incomplete, sorter)`.

### Guarantees

- **No mixing.** An image is reported only when its stream passes CRC-32 *and*
  hashes to its own image id.
- **Merging.** Identical frames — re-sends, or the same image from two
  stations — merge silently, before and after the image completes.
- **No exceptions from traffic.** Unparseable text is counted in
  `sorter.rejected` and dropped; `sorter.add` never raises on bad input.
- **Bounded memory.** Pending sets (64), frames per set (48), and remembered
  completed images (256) are capped, oldest first; evicted sets are recorded in
  `sorter.evicted`.
- **No timing policy.** How long an incomplete set may wait belongs to the
  channel layer. The sorter only offers `expire`; it never abandons a set on its
  own.

### When two images share an id

With 4-character ids a collision is rare: about 1 in 300,000 new images when 50
sets are live in a receiver, against 1 in 5,000 with the 3 characters protocol 6
used. When it happens, the sorter keeps every frame and tries candidate
assemblies, most complete first, including leaving out a held frame and
rebuilding that part from parity — a slot can hold the *other* image's frame.
A wrong assembly fails its CRC or id check, so each candidate is proven or
discarded, never trusted. Disproved assemblies are remembered, and at most 512
new ones are tried per arriving message, so a set flooded with conflicting
frames costs bounded time.

Measured by forcing collisions (the id space shrunk to one or two values):

| Colliding images, each losing 0–2 messages | Every image separated | Wrong decodes | Worst time per message |
|---|---|---|---|
| 2–4 small images (k ≈ 1–4), 240 streams | 240 / 240 | 0 | under 0.2 s per stream |
| 2 full-size images (k = 8) on one id | 5 / 5 | 0 | 82 ms |
| 3 full-size images (k = 8) on one id | 5 / 5 | 0 | 536 ms |
| 4 full-size images (k = 8) on one id | 1 / 5 | 0 | 604 ms |

Four full-size images on one id exceed the search budget and stay pending,
flagged as conflicting. That is a limit, not a correctness failure; at real id
widths it is far outside plausible traffic.

---

## Results

### `EncodedImage`

| Field | Meaning |
|---|---|
| `raw` | Compressed bytes plus stream CRC-32 |
| `payload` | Base91 text |
| `frames` | Data frames |
| `parity_frames` | P and Q, empty when the image does not fit or `parity=False` |
| `transmit_frames` | What to send: `frames + parity_frames` |
| `stats` | `CodecStats` |
| `image_id` | Stream identifier |
| `palette` | Ordered colour table |

### `CodecStats`

| Field | Meaning |
|---|---|
| `command_count` | Commands actually transmitted |
| `source_command_count` | Commands before planning |
| `palette_count` | Colours used |
| `bit_count` | Compressed size in bits |
| `packed_bytes` | Bytes including stream CRC |
| `base91_chars` | Payload characters |
| `frame_count` | Messages required |
| `repeat_count` | Single plus group repeats |
| `group_repeat_count` | Group repeats and transform references |
| `primitive_count` | Primitives kept compact |
| `vectorized_primitive_count` | Primitives expanded to vectors |
| `transformed_group_count` | Local-space groups emitted |
| `transformed_group_reference_count` | Reused local definitions |
| `local_group_extent` | Precision the encoder settled on |
| `coding_mode` | `1` entropy-coded, `0` raw |
| `parity_frame_count` | 2 when parity was added, else 0 |

`stats.fits` reports whether the data is within the ten-message budget; parity
sits outside it. `stats.message_count` is everything actually transmitted.

---

## Editing this file

**Mirror every change.** A writer change must be mirrored in its reader, in both
syntax *and* context. Both must be exercised by round-trip fixtures.

**Bit changes are protocol changes.** If unchanged input produces different
bits, bump `PROTOCOL_VERSION` and update the Reconstructor in the same commit.

**Encoder-only changes are not.** Simplification tolerance, planning heuristics,
and search strategy affect size without changing the format. Those ship freely.

**Keep it re-entrant.** Local-coordinate precision is passed as an argument, not
held in module state. Do not reintroduce mutable module-level configuration.

**Do not import upward.** The codec may import the model, never the Constructor
or the Reconstructor.

### Verifying a change

Because protocol changes intentionally alter the bytes, byte-level golden
fixtures stop applying. Correctness is proven by **semantic round trip**
instead: what the decoder returns must equal what the encoder promised to send.

```python
enc = mci.encode_image(commands)
decoded  = mci.decode_frames(enc.frames)
promised = mci.decode_commands(enc.raw[:-4], enc.stats.coding_mode)[0]
assert [c.to_json() for c in decoded] == [c.to_json() for c in promised]
```

Both self-tests must pass:

```bash
python MCoreIMG-Constructor.py --self-test
python MCoreIMG-Reconstructor.py --self-test
```

---

## Known limitations

- Planning is contextual and greedy rather than globally optimal.
- Group repeats match under translation only. The symmetry search is applied to
  single commands, where the candidate set is one reference per opcode and the
  search is cheap.
- Scaled repeats are not detected outside local-space groups.
- The 32-colour palette is a hard protocol limit, not a tunable.
- Base91's ~1.22× expansion is unavoidable while MeshCore carries text. A
  binary-safe transport would recover roughly 18% immediately.
