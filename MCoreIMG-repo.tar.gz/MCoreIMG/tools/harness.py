"""Shared helpers for the MCoreIMG test and benchmark tools.

Everything here resolves paths relative to the repository root, so the tools
run from a clone without editing anything.
"""
import importlib.util
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLES = os.path.join(ROOT, "samples")

CONSTRUCTOR = os.path.join(ROOT, "MCoreIMG-Constructor.py")
COMPRESSION = os.path.join(ROOT, "MCoreIMG-compression.py")
MODEL = os.path.join(ROOT, "MCoreIMG-model.py")
RECONSTRUCTOR = os.path.join(ROOT, "MCoreIMG-Reconstructor.py")


def load(name, path):
    """Import a hyphenated module file by path, registering it first."""
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_constructor():
    """Load the Constructor, which pulls in the codec and model beneath it."""
    return load("ctor", CONSTRUCTOR)


def load_codec():
    """Load the codec alone, for tests that need no GUI or renderer."""
    return load("mcoreimg_compression", COMPRESSION)


# --------------------------------------------------------------------------
# Sample corpus
# --------------------------------------------------------------------------
#
# These are real assets, not synthetic ones. An earlier synthetic corpus was
# written to exercise the features being developed and reported roughly 20%
# gains that turned out to be 0.14% on real tracer output. Measure here.

SVG_SAMPLES = {
    "aflaq_portrait": "Michel_Aflaq_and_Salah_Jadid_in_1963_thumbnail.svg",
    "atassi_portrait": "Louai_and_Jamal_Atassi_thumbnail.svg",
}
SOURCE_SAMPLES = {"grass_cart": "644charCart_mci.json"}

# Payload characters for each sample on the current build, with 120-character
# channel messages. Used as the regression reference by tools/measure.py.
REFERENCE = {"aflaq_portrait": 1334, "atassi_portrait": 1083, "grass_cart": 638}

# Whether each sample fits ten 120-character data frames. The Aflaq portrait
# needs 12 even at the coarsest local precision, so it is the over-budget case:
# tests check it is reported honestly rather than skipping it.
FITS = {"aflaq_portrait": False, "atassi_portrait": True, "grass_cart": True}


def build_corpus(ctor):
    """Return {name: [VectorCommand]} loaded from the sample files."""
    out = {}
    for name, filename in SVG_SAMPLES.items():
        path = os.path.join(SAMPLES, filename)
        if not os.path.exists(path):
            continue
        commands = ctor.import_svg(path).transformed_commands()
        ctor.assign_editor_group(commands, 1)  # what the GUI does on import
        out[name] = commands
    for name, filename in SOURCE_SAMPLES.items():
        path = os.path.join(SAMPLES, filename)
        if not os.path.exists(path):
            continue
        out[name] = ctor.load_source(path).transformed_commands()
    return out
