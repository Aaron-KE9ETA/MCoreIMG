#!/usr/bin/env python3
"""Generate RAID 6 parity fixtures for verifying a port of the parity layer.

Writes tests/fixtures/parity_fixtures.json, produced directly from the Python
reference. A port passes when, for every case, it emits the same P and Q
frames from the data frames, and rebuilds exactly the listed data frames for
every loss pattern. Zero mismatches is the bar.

    python tools/make_parity_fixtures.py
"""
import itertools
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import ROOT, build_corpus, load_constructor


def case(m, name, data_frames):
    parity = m.build_parity_frames(data_frames)
    sent = list(data_frames) + parity
    patterns = [list(p) for p in itertools.chain(itertools.combinations(range(len(sent)), 1),
                                                 itertools.combinations(range(len(sent)), 2))]
    for lost in patterns:   # the fixture must itself be correct
        rebuilt = m.reassemble_frames([f for i, f in enumerate(sent) if i not in lost])
        assert rebuilt.frames == list(data_frames), (name, lost)
    return {"name": name, "k": len(data_frames), "data_frames": list(data_frames),
            "parity_frames": parity, "loss_patterns": patterns,
            "note": "for every loss pattern, reassembly must return data_frames exactly"}


def write_sorter_fixtures(m, ctor):
    """Interleaved channel streams with the arrival at which each image completes.

    For streams without id collisions the earliest completing arrival is fully
    determined: an image completes on the first message after which its data
    frames, plus any parity, can rebuild it. A port's receive engine must report
    the same image at the same arrival, with the same rebuilt parts.
    """
    corpus = build_corpus(ctor)
    encoded = [e for e in (m.encode_image(cmds) for cmds in corpus.values()) if e.stats.fits]
    rng = random.Random(1017)
    streams = []
    for index in range(8):
        stream = []
        for e in encoded:
            sent = e.transmit_frames
            lost = set(rng.sample(range(len(sent)), rng.choice([0, 1, 2])))
            stream += [f for i, f in enumerate(sent) if i not in lost]
        if index % 2:
            stream += rng.sample(stream, 3)                       # re-sends
            stream += ["<N9AJC> 73", "MCI not a frame"]          # channel chatter
        rng.shuffle(stream)
        sorter = m.FrameSorter()
        events = []
        for arrival, frame in enumerate(stream):
            for image in sorter.add(frame, now=float(arrival)):
                events.append({"arrival": arrival, "image_id": image.image_id, "k": image.k,
                               "recovered": image.recovered, "data_frames": image.frames})
        streams.append({"frames": stream, "completions": events,
                        "pending_at_end": [st.image_id for st in sorter.pending()],
                        "duplicates": sorter.duplicates, "rejected": sorter.rejected})
    out = {"generator": "tools/make_parity_fixtures.py", "codec_build": m.COMPRESSION_BUILD,
           "protocol": m.PROTOCOL_VERSION, "image_id_len": m.IMAGE_ID_LEN,
           "note": ("Feed frames one at a time in order. Each completion must be reported at "
                    "the given arrival index with the same id, k, rebuilt parts, and data frames."),
           "streams": streams}
    dest = os.path.join(ROOT, "tests", "fixtures", "sorter_fixtures.json")
    with open(dest, "w", encoding="ascii") as fh:
        json.dump(out, fh, indent=1)
    total = sum(len(st["completions"]) for st in streams)
    print(f"wrote {dest}: {len(streams)} interleaved streams, {total} completions")


def main():
    ctor = load_constructor()
    m = ctor.mci
    cases = []
    for name, cmds in build_corpus(ctor).items():
        frames = m.encode_image(cmds, parity=False).frames
        if frames:   # an over-budget sample has nothing to protect
            cases.append(case(m, name, frames))

    # Edge cases: single-frame images of odd and even length, and a final
    # frame that ends in the pad symbol, which the length search must handle.
    rng = random.Random(61)
    VC, PS = m.VectorCommand, m.PaintStyle
    wanted = {"single_odd": None, "single_even": None, "final_ends_in_pad": None}
    for seed in range(4000):
        if all(wanted.values()):
            break
        r = random.Random(seed)
        shapes = [VC(m.OP_RECT, PS(r.choice(["#204060", "#C0A080", "#FF0000"]), None, 1.0),
                     {"x": r.randrange(600), "y": r.randrange(400),
                      "w": r.randrange(2, 90), "h": r.randrange(2, 70)})
                  for _ in range(r.randrange(1, 90))]
        frames = m.encode_image(shapes, parity=False).frames
        if not frames:
            continue
        tail = frames[-1][m.FRAME_HEADER_LEN:]
        if len(frames) == 1 and len(tail) % 2 and not wanted["single_odd"]:
            wanted["single_odd"] = frames
        elif len(frames) == 1 and not len(tail) % 2 and not wanted["single_even"]:
            wanted["single_even"] = frames
        elif len(frames) > 1 and tail.endswith(m.BASE91[0]) and not wanted["final_ends_in_pad"]:
            wanted["final_ends_in_pad"] = frames
    for name, frames in wanted.items():
        if frames:
            cases.append(case(m, name, frames))

    out = {
        "generator": "tools/make_parity_fixtures.py",
        "codec_build": m.COMPRESSION_BUILD,
        "protocol": m.PROTOCOL_VERSION,
        "parity_magic": m.PARITY_MAGIC,
        "field": {
            "gf13_generator": m._G13,
            "gf49_generator": m._G49,
            "gf49_encoding": "e = re + 7*im, with i^2 = -1 over GF(7)",
            "coef13": m._COEF13,
            "coef49": m._COEF49,
            "crt": "symbol = (78*r7 + 14*r13) % 91",
            "pad_symbol": m.BASE91[0],
            "descriptor": "which + 2*(k-1) + 20*mode; which 0=P 1=Q",
            "header": "magic(3) + image id(4) + descriptor(1)",
        },
        "cases": cases,
    }
    write_sorter_fixtures(m, ctor)

    dest = os.path.join(ROOT, "tests", "fixtures", "parity_fixtures.json")
    with open(dest, "w", encoding="ascii") as fh:
        json.dump(out, fh, indent=1)
    total = sum(len(c["loss_patterns"]) for c in cases)
    print(f"wrote {dest}: {len(cases)} cases, {total} loss patterns, all self-verified")
    for c in cases:
        print(f"  {c['name']:20s} k={c['k']:2d} patterns={len(c['loss_patterns'])}")


if __name__ == "__main__":
    sys.exit(main())
