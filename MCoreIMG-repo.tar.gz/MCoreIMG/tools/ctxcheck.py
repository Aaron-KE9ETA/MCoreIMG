#!/usr/bin/env python3
"""Verify the encoder and decoder walk identical entropy-context sequences.

An adaptive range coder fails silently when a writer and its reader disagree
about which probability model a bit belongs to: raw mode keeps working, so only
entropy-coded images corrupt, and the error surfaces far from its cause. This
records both sequences and reports the first divergence.

    python tools/ctxcheck.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import build_corpus, load_constructor


def main():
    ctor = load_constructor()
    m = ctor.mci
    corpus = build_corpus(ctor)

    writer_ops = []
    original = m.BitWriter.to_bytes_rc

    def traced(self):
        writer_ops.clear()
        for kind, ctx, bit in self.ops:
            writer_ops.append(("<bypass>" if kind == "d" else ctx, bit))
        return original(self)

    m.BitWriter.to_bytes_rc = traced

    Decoder = m.RangeDecoder
    real_bit, real_direct = Decoder.decode_bit, Decoder.decode_direct
    reader_ops = []

    def traced_bit(self, ctx):
        b = real_bit(self, ctx)
        reader_ops.append((ctx, b))
        return b

    def traced_direct(self):
        b = real_direct(self)
        reader_ops.append(("<bypass>", b))
        return b

    checked = failures = 0
    for name, cmds in corpus.items():
        enc = m.encode_image(cmds)
        if not enc.stats.coding_mode:
            print(f"  n/a  {name}: raw mode, contexts unused")
            continue
        ops = list(writer_ops)
        reader_ops.clear()
        Decoder.decode_bit, Decoder.decode_direct = traced_bit, traced_direct
        error = None
        try:
            m.decode_commands(enc.raw[:-4], 1)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        Decoder.decode_bit, Decoder.decode_direct = real_bit, real_direct

        checked += 1
        diverged = next((i for i, (a, b) in enumerate(zip(ops, reader_ops)) if a != b), None)
        if diverged is None and len(ops) != len(reader_ops):
            diverged = min(len(ops), len(reader_ops))
        if diverged is None and error is None:
            print(f"  PASS {name}: {len(ops)} ops symmetric")
        else:
            failures += 1
            print(f"  FAIL {name}: writer {len(ops)} ops, reader {len(reader_ops)} ops")
            if error:
                print(f"        {error}")
            if diverged is not None:
                lo = max(0, diverged - 5)
                print(f"        first divergence at op {diverged}")
                print(f"        writer: {ops[lo:diverged + 3]}")
                print(f"        reader: {reader_ops[lo:diverged + 3]}")

    print(f"\n{checked - failures}/{checked} entropy-coded cases symmetric")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
