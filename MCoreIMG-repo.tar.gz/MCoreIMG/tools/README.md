# Tools

| Tool | Purpose |
|---|---|
| `harness.py` | Shared loader and sample-corpus builder. Not run directly. |
| `measure.py` | Benchmark payload, frames, encode time, and geometric deviation. |
| `ctxcheck.py` | Verify encoder/decoder entropy-context symmetry. |
| `make_parity_fixtures.py` | Regenerate `tests/fixtures/parity_fixtures.json` and `sorter_fixtures.json` for port verification. |

All paths resolve relative to the repository root, so these run from a clone
without editing.

```bash
python tools/measure.py [--verbose]
python tools/ctxcheck.py
```

## Why measure against `samples/`

An earlier synthetic corpus was written to exercise the features being
developed at the time. It reported roughly 20% gains that turned out to be
0.14% on real tracer output. `samples/` holds real assets; benchmark there.

`REFERENCE` in `harness.py` records the payload size of each sample on the
current build. Update it deliberately when a change is accepted, so an
unexplained movement shows up as a diff.

## ctxcheck matters more than it looks

With an adaptive range coder, a writer and reader disagreeing about which
probability model a bit belongs to is a **silent** failure: raw mode keeps
working, so only entropy-coded images corrupt, and the error surfaces far from
its cause as an `IndexError` or a nonsense opcode. Three such mismatches were
introduced while building the coder; none were findable by reading the code.

Run it after any change to a record writer or reader.

## Note on Tkinter

These tools import the Constructor, which imports Tkinter at module level.
Tkinter must be installed, though no display is needed. A headless machine can
still decode and export JSON via `MCoreIMG-Reconstructor.py --no-render`.
