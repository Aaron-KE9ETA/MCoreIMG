# MCoreIMG Reconstructor

The receiving half of MCoreIMG. Turns transport frames, or an editable source
file, back into a raster image.

> **Build:** `2026.10.17-reconstructor-v7.0-MULTIIMAGE`
> **Depends on:** `MCoreIMG-compression.py` for decoding, `MCoreIMG-Constructor.py` for rendering

The Reconstructor contains **no codec of its own**. Decoding is done by the
compression module and rendering by the Constructor, so the receiver can never
drift from the transmitter.

---

## How this differs from earlier builds

Previous versions could not simply import the codec, because the Constructor was
a single file with several historical implementation layers and no stable public
API. To cope, this program carried roughly seven hundred lines of reflection: it
scanned candidate files, ranked them by a feature score, searched modules and
classes for anything resembling a decoder or renderer, and tried several calling
conventions until one bound successfully.

The codec is now an importable module with an explicit `__all__`. All of that
discovery machinery is gone.

The failure it was protecting against — a receiver paired with the wrong
transmitter — is now caught directly by comparing protocol numbers and reporting
every build string involved.

---

## Requirements

### Required

- Python 3.10 or newer
- `MCoreIMG-compression.py` and `MCoreIMG-model.py` for decoding
- `MCoreIMG-Constructor.py` and Pillow for rendering

### Optional

- Tkinter/Tk — only for the interactive file chooser when no input path is
  given on the command line

Decoding and JSON export work without Pillow or a display when `--no-render` is
used, which makes the Reconstructor usable on a headless relay host.

---

## File layout

Keep all four modules together:

```
mcoreimg/
├── MCoreIMG-model.py
├── MCoreIMG-compression.py
├── MCoreIMG-Constructor.py
└── MCoreIMG-Reconstructor.py
```

Each lookup falls back to the directory beside this file, then the working
directory, and can be overridden with `--compression` or `--constructor`.

---

## Quick start

### Reconstruct a frame file

```bash
python MCoreIMG-Reconstructor.py received.mci
```

Decodes, validates, renders a PNG beside the input, and opens it.

### Choose the input interactively

```bash
python MCoreIMG-Reconstructor.py
```

### Decode without rendering

```bash
python MCoreIMG-Reconstructor.py received.mci --no-render --list-commands
```

### Recover editable source

```bash
python MCoreIMG-Reconstructor.py received.mci --dump-json
```

### Verify the installed set

```bash
python MCoreIMG-Reconstructor.py --show-core
python MCoreIMG-Reconstructor.py --self-test
```

---

## Command-line options

| Option | Purpose |
|---|---|
| `input` | `.mci`, text, `.mci.json`, `.json`, `.svg`, or `.svgz` file |
| `-o`, `--output PATH` | Output PNG path |
| `--compression PATH` | Path to `MCoreIMG-compression.py` |
| `--constructor PATH` | Path to `MCoreIMG-Constructor.py` |
| `--protocol N` | Require a specific protocol number |
| `--dump-json` | Write a Constructor-compatible source JSON |
| `--list-commands` | Print the decoded command stream |
| `--no-render` | Decode only; do not produce a PNG |
| `--no-open` | Do not automatically open the PNG |
| `--self-test` | Run codec and rendering round-trip tests |
| `--show-core` | Print the loaded modules and exit |

### Exit codes

| Code | Meaning |
|---|---|
| 0 | Success: at least one image decoded (incomplete sets are listed on stderr) |
| 1 | Interactive chooser cancelled |
| 2 | No image could be decoded, or a compatibility error |
| 130 | Interrupted with Ctrl-C |

---

## Supported input

### Several images in one input

A transport input may hold messages from any number of images — a saved
channel log, for instance — interleaved, out of order, with duplicates and
chatter. They are sorted into per-image sets by image id and each complete
image is decoded on its own:

```text
Input: 27 frame(s) from channel.log, 3 image(s) decoded, 1 incomplete
Incomplete: liKl: 3 data frame(s), 0 parity; total unknown until the final frame or a parity frame arrives
Loaded: image ceBP: 8/10 data + 2/2 parity frame(s); rebuilt part(s) 2, 7 from parity
```

With one image, output is written exactly as before. With several, each PNG
(and `--dump-json` file) takes the output name with the image id appended:
`channel-ceBP.png`, `channel-LpOZ.png`. Several images are not opened
automatically.

### MCoreIMG transport

A `.mci` file with one frame per line, or any text containing complete frames.
Data frames are located by their `MCI` magic and parity frames by `MCP`, each
validated individually, so pasted chat transcripts with surrounding
conversation work as input.

Up to two missing messages are rebuilt from parity. The report says what
arrived and what was rebuilt:

```text
Loaded: 8/10 data + 2/2 parity frame(s) from chat.txt; rebuilt part(s) 3, 7 from parity
```

A third loss is refused, naming the missing parts:

```text
Frame decoding failed: Missing data parts 3, 5, 8 of 10. 2 of 2 parity frame(s)
received, enough to rebuild 2 missing part(s).
```

### Editable MCoreIMG source

`.mci.json` and `.json` files are handed to the Constructor's source loader and
rendered directly. This path never touches the codec.

### SVG source

`.svg` and `.svgz` files are imported through the Constructor and rendered,
which is useful for previewing what artwork will look like after transport.

---

## Data flow

### Transport path

```
input text/.mci
    -> extract and validate complete MCI frames
    -> check the protocol number in the frame header
    -> mci.decode_frames(frames)          CRC and envelope validation
    -> ctor.render_to_pillow(commands)
    -> save PNG, optionally export editable JSON
```

### Source path

```
.mci.json / .json / .svg / .svgz
    -> ctor.load_source(path)
    -> document.transformed_commands()
    -> ctor.render_to_pillow(commands)
```

---

## Frame parsing and validation

Frame text is scanned before a codec is chosen, so the program keeps four
bootstrap constants (`FRAME_MAGIC`, `PARITY_MAGIC`, `BASE62`, header length
of 8, message length).
These are **verified against the codec** as soon as it loads. If the transport
profile ever changes, the mismatch is reported rather than silently tolerated.

`extract_frames` recovers complete frames from noisy text and deduplicates
them. It does not assume they belong to one image: the codec's `FrameSorter`
sorts them into per-image sets by image id.

There is no length field, so frame boundaries are found differently:
chunking fills every frame except the last, so a non-final frame is always
exactly 120 characters and can be sliced out of a line containing several. A
final frame runs to the end of its line. The part descriptor in the header says
which kind it is. A parity frame's descriptor carries the data frame count k:
with k > 1 it is exactly 120 characters, and with k = 1 it runs to the end of
its line.

Decoding then rejects frames that are the wrong length, carry the wrong magic or
protocol, declare an out-of-range index, disagree about the coding mode, carry a
short non-final payload, come from a different image, conflict with a duplicate,
declare two different final frames, or fail the stream CRC-32. A gap in the
sequence is refused only when the parity received cannot fill it.

There is no per-frame CRC. MeshCore guarantees the integrity of a
delivered message, so the per-frame check was redundant on that path. Frames
pasted from a chat transcript leave MeshCore's protection, and for those the
stream CRC-32 still detects corruption — it just reports that the set is bad
rather than naming the offending frame. Parity does not change that: it
rebuilds *missing* messages, but cannot locate a corrupted one.

---

## Protocol matching

Since protocol 7 the frame magic names the format, so a frame recognised as
`MCI` or `MCP` is a protocol-7 frame; the Reconstructor's bootstrap copy of that
protocol number is checked against the codec when it loads. The codec must also
agree with the Constructor. Editable source files are not checked: their
`protocol_version` records where they came from and does not stop them
rendering.

- Input versus codec is checked before decoding.
- Codec versus Constructor is checked at load time.
- `--protocol N` adds an explicit assertion for scripted use.

Any mismatch produces exit code 2 and an error naming the files and their build
strings. For example:

```text
Reconstruction failed:
Input needs protocol 6, but the codec beside this file is protocol 7.
  Codec: /path/to/MCoreIMG-compression.py
Pair this Reconstructor with the matching codec, or pass --compression.
```

Transports older than protocol 7 are not decodable by this build: the frame
header changed. A protocol-6 frame is not recognised as anything else — it
simply fails its id check and is reported as an incomplete or undecodable set.
Use a Reconstructor and codec pair from the matching generation.

---

## Module loading

Both siblings use hyphenated filenames, which are not legal Python identifiers,
so they are loaded by path.

Import order matters. The codec is loaded first and registered in `sys.modules`;
the Constructor then reuses that same module object rather than creating a
second one. This is deliberate — two copies would define two distinct
`VectorCommand` classes, and objects decoded by one would not be recognised by
the other.

`--no-render` makes the Constructor optional, so a headless host can decode and
export JSON with only the codec and model present.

---

## Self-test

```bash
python MCoreIMG-Reconstructor.py --self-test
```

Ten checks:

1. A simple document survives a full frame round trip.
2. Frames are recovered from surrounding chat noise.
3. A corrupted frame is rejected rather than silently rendered.
4. An incomplete frame set without parity is rejected.
5. A recognised frame magic implies the codec's protocol.
6. Rendering produces a canvas-sized image, when a Constructor is present.
7. A multi-frame image survives every 1- and 2-message loss, in shuffled order.
8. Every 3-message loss is refused rather than mis-decoded.
9. Parity frames are found in pasted text, including several on one line.
10. Three images interleaved on one channel, each losing a message, with
    re-sends and chatter, decode separately and correctly.

Successful output:

```text
MCoreIMG Reconstructor self-test: PASS (10 checks)
protocol=7 frames=1 commands=2 parity_patterns=15
```

---

## Output

### PNG

Written beside the input unless `-o` is given, and opened automatically unless
`--no-open` is passed. The image is rendered by the Constructor's authoritative
Pillow renderer, so it matches what the sender previewed.

### Editable JSON

`--dump-json` writes a Constructor-compatible source document containing the
decoded commands plus a `reconstructed` block recording the Reconstructor build,
the timestamp, the input filename, and the codec build.

This is a best-effort recovery. Rendering can be lossless even when authoring
metadata — editor grouping, layer labels, the original document transform —
cannot be recovered, because those are not transmitted.

The result loads back into the Constructor and re-encodes to the same frames.

---

## Module structure

| Section | Contents |
|---|---|
| Bootstrap frame constants | The few values needed before a codec is chosen |
| Module loading | Path-based import, pairing checks, `Core` container |
| Frame text handling | Base62 headers, frame extraction, protocol detection |
| Input classification | Transport versus source, output paths, opening files |
| JSON export | Best-effort editable source recovery |
| Decode, render, export | The actual pipeline |
| Self-test | Round-trip and corruption checks |
| Command line | Parser, diagnostics, orchestration |

---

## Development notes

- The Reconstructor must never implement decoding. If it needs a codec
  behaviour it does not have, add it to `MCoreIMG-compression.py` and export it.
- Bootstrap constants are the one permitted duplication, and only because frame
  scanning must precede codec selection. They are checked against the codec at
  load time; keep that check working.
- Prefer clear pairing errors over silent fallbacks. The whole point of the
  rewrite was replacing guesswork with explicit checks.
