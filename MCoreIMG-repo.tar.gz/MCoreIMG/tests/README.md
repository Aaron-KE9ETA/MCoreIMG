# Tests

```bash
python tests/run_all.py          # everything
python tests/test_integration.py # cross-module checks only
python tests/test_parity_fixtures.py  # parity layer against frozen fixtures
```

`run_all.py` runs both module self-tests, the entropy-context symmetry check,
the integration suite, and the benchmark.

## What is covered

- **Module self-tests** (`--self-test` on both tools): codec round trips,
  frame extraction from noisy text, corruption rejection, build-integrity
  pairing, canvas click routing, and the precision-ladder search.
- **Integration**: module layering, CLI surfaces, round trips on the real
  samples, end-to-end through both tools, determinism, scale stability,
  malformed-input rejection, and mismatched-pair detection.
- **Context symmetry**: see `tools/README.md`.
- **Port fixtures**: the reference must reproduce
  `fixtures/sorter_fixtures.json` — for interleaved multi-image streams, the
  exact arrival at which each image completes — and
  `fixtures/parity_fixtures.json` exactly — P and Q from the data frames, and
  the original data frames from every 1- and 2-message loss. A failure means
  the parity layer changed, which is a wire-format change. The same file is
  the contract a port is verified against.

## What is not covered

The GUI has no automated coverage, because it needs a display. Interactive
behaviour is verified by hand against the checklist in the root README.
